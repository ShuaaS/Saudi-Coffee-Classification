import torch
import torch.nn as nn
import torch.nn.functional as F


class TransformerBlock(nn.Module):
    def __init__(self, d_model, n_heads, dim_feedforward=128, dropout=0.1):
        super().__init__()

        self.attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        ## Reshape
        src = x.view((x.shape[0], x.shape[1], x.shape[2]*x.shape[3]))

        # Self-attention layer
        src2 = self.attn(src, src, src, attn_mask=mask)[0]
        src = src + self.dropout1(src2)
        src = self.norm1(src)

        # Feedforward layer
        src2 = self.linear2(self.dropout(F.relu(self.linear1(src))))
        src = src + self.dropout2(src2)
        src = self.norm2(src)

        src = src.view((x.shape[0], x.shape[1], x.shape[2], x.shape[3]))

        return src


if __name__ == "__main__":
    x = torch.randn((8, 256, 7, 7))

    block = TransformerBlock(49, 7)
    y = block(x)
    print(y.shape)
